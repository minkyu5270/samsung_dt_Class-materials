//함수 선언부
function myfunc(){
    console.log("myfunc함수가 실행되었습니다.");
}

myfunc(); //호출부