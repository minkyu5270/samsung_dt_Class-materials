//객체 구조분해할당(비구조화 할당)
//as로 할당받은 객체의 이름을 변경할 수 있다.
import { hi, goodbye as bye } from "./08-4-greeting.mjs";

hi("변사또");
//goodbye("김삿갓");
bye('김진사');