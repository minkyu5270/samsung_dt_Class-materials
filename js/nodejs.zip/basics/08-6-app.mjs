import * as say from "./08-4-greeting.mjs";

say.hi("hong");
say.goodbye("kim");