//import goodbye from "./08-2-goodbye-1.mjs";
import { goodbye } from "./08-2-goodbye-2.mjs";

goodbye('홍길동');

