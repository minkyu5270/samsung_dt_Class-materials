const goodbye = (name) => {
    console.log(`${ name } 님, 안녕히가세요.`);
};

//export default - 일반적으로 해당 모듈에 하나의 개체만 존재할 때 주로 사용.
//내보내기 할 객체 - 변수, 클래스, 함수 등
export default goodbye;