//첫번째 노드 프로그램 실행하기
function hello(name){
    console.log(`${name}님 환영합니다.`);
}

hello('홍길동');