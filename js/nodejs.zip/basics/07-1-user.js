//사용자의 이름을 저장하는 변수 - user.js
const user = '홍길동';

module.exports = user; //user 변수를 내보내기