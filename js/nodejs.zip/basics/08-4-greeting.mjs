const hi = (name) => {
    console.log(`${ name } 님, 안녕하세요?`);
};

const goodbye = (name) => {
    console.log(`${ name } 님, 안녕히가세요~`);
};

//여러개 내보내기
export { hi, goodbye };