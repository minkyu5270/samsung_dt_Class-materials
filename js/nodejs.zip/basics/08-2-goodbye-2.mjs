//export default의 간략한 표현
export const goodbye = (name) => {
    console.log(`${ name } 님, 안녕히가세요.`);
};
