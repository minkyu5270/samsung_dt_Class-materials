//연습문제
//07-1-user.js와 07-4-buy.js 모듈을 이용하여
//'홍길동 님, 안녕히 가세요.'라고 표시하는 코드를 작성하시오.

const user = require("./07-1-user.js");
const buy = require("./07-4-buy.js");

buy( user );