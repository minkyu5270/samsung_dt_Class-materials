const buy = (name) => {
    console.log( `${ name } 님, 안녕가세요.` );
};

module.exports = buy; //buy 함수 내보내기