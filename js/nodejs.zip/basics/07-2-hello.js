//터미널에 사용자이름을 출력해주는 함수 - hello.js
const hello = (name) => {
    console.log( `${ name } 님, 안녕하세요?` );
};

module.exports = hello; //hello 함수 내보내기