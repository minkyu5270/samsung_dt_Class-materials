//user와 hello 임포트하여 사용하기
const user = require("./07-1-user.js");
const hello = require("./07-2-hello.js");

hello( user );